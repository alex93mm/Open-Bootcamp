package com.example;

import org.springframework.stereotype.Component;

@Component
public class NotificationService {

    public NotificationService(){}

    public void notification(){

        System.out.println("Esta es una notificacion importante...");

    }

}
